import SwiftUI

/// Redaction preserves the real controls. Shimmer decorates that same subtree.
public struct CNSkeleton<Content: View>: View {
    private let isLoading: Bool
    private let classes: TWClasses
    private let content: Content
    public init(isLoading: Bool = true, classes: TWClasses = "", @ViewBuilder content: () -> Content) {
        self.isLoading = isLoading; self.classes = classes; self.content = content()
    }
    public var body: some View {
        content.redacted(reason: isLoading ? .placeholder : []).disabled(isLoading)
            .accessibilityHidden(isLoading)
            .tw(cn("feedback-motion", isLoading ? "skeleton skeleton-motion" : "", classes),
                value: isLoading, animationScope: .surface)
            .loadingUtilities()
    }
}

/// A continuous circular arc with a quiet track, independent of platform spinner chrome.
public struct CNSpinner: View {
    private let title: LocalizedStringKey
    private let lineWidth: CGFloat
    private let classes: TWClasses
    public init(_ title: LocalizedStringKey = "Loading", lineWidth: CGFloat = 2, classes: TWClasses = "") {
        precondition(lineWidth.isFinite && lineWidth > 0)
        self.title = title; self.lineWidth = lineWidth; self.classes = classes
    }
    public var body: some View {
        ZStack {
            Circle().inset(by: lineWidth / 2).stroke(lineWidth: lineWidth).opacity(0.15)
            Circle().inset(by: lineWidth / 2).trim(from: 0.04, to: 0.76)
                .stroke(style: StrokeStyle(lineWidth: lineWidth, lineCap: .round))
        }.tw(cn("spinner spinner-motion", classes)).loadingUtilities()
            .accessibilityElement(children: .ignore).accessibilityLabel(title).accessibilityValue("In progress")
    }
}

/// Seconds are literal or interpolated arguments. Zero turns the effect off.
public enum CNLoadingUtilities {
    public static let shimmer: TWNativeUtility = .argument(default: "0", conflictKey: "cn-shimmer") { argument, _ -> CNShimmerModifier? in
        guard let duration = argument.value(as: Double.self), duration.isFinite, duration >= 0 else { return nil }
        return CNShimmerModifier(duration: duration)
    }
    public static let spin: TWNativeUtility = .argument(default: "0", conflictKey: "cn-spin") { argument, _ -> CNSpinModifier? in
        guard let duration = argument.value(as: Double.self), duration.isFinite, duration >= 0 else { return nil }
        return CNSpinModifier(duration: duration)
    }
}
private extension View {
    func loadingUtilities() -> some View {
        twRules {
            if $0.modifiers["cn-shimmer"] == nil { $0.modifiers["cn-shimmer"] = CNLoadingUtilities.shimmer }
            if $0.modifiers["cn-spin"] == nil { $0.modifiers["cn-spin"] = CNLoadingUtilities.spin }
        }
    }
}

public struct CNShimmerModifier: ViewModifier {
    private let duration: Double
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.layoutDirection) private var direction
    public nonisolated init(duration: Double) {
        precondition(duration.isFinite && duration >= 0)
        self.duration = duration
    }
    public func body(content: Content) -> some View {
        content.mask {
            ZStack {
                Color.white.opacity(duration > 0 && !reduceMotion ? 0.6 : 1)
                CNLoadingTimeline(duration: duration) { phase in
                    GeometryReader { geometry in
                    let bandWidth = max(1, geometry.size.width * 0.55)
                    let offset = -bandWidth + phase * (geometry.size.width + bandWidth)
                    LinearGradient(colors: [.clear, .white, .clear],
                                   startPoint: .leading, endPoint: .trailing)
                        .frame(width: bandWidth)
                        .offset(x: direction == .leftToRight ? offset : geometry.size.width - bandWidth - offset)
                    }.clipped().opacity(duration > 0 && !reduceMotion ? 1 : 0)
                }
            }
        }
    }
}
public struct CNSpinModifier: ViewModifier {
    private let duration: Double
    @State private var phase: Double = 0
    @Environment(\.cnLoadingPhase) private var fixedPhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    public nonisolated init(duration: Double) {
        precondition(duration.isFinite && duration >= 0); self.duration = duration
    }
    public func body(content: Content) -> some View {
        let angle = duration == 0 ? 0 : fixedPhase ?? (reduceMotion ? 0 : phase)
        content.rotationEffect(.degrees(angle * 360)).background {
            CNLoadingTimeline(duration: duration) { value in
                Color.clear.onChange(of: value, initial: true) { _, value in phase = value }
            }.allowsHitTesting(false).accessibilityHidden(true)
        }
    }
}
private struct CNLoadingTimeline<Content: View>: View {
    let duration: Double
    let content: (Double) -> Content
    @State private var origin = Date.now
    @State private var visible = false
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.cnLoadingPhase) private var fixedPhase
    var body: some View {
        let paused = duration == 0 || reduceMotion || fixedPhase != nil || !visible || scenePhase != .active
        TimelineView(.animation(minimumInterval: 1 / 30, paused: paused)) { context in
            let phase = duration == 0 ? 0 : fixedPhase ?? (!reduceMotion
                ? max(0, context.date.timeIntervalSince(origin)).truncatingRemainder(dividingBy: duration) / duration : 0)
            content(phase)
        }.onAppear { origin = .now; visible = true }.onDisappear { visible = false }
    }
}
